from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

# Simple rule-based chatbot logic
def get_bot_response(user_message):
    user_message = user_message.lower().strip()
    
    # Admission-related patterns and responses
    patterns = [
        (r'apply|application|how to apply', 
         "To apply, visit our university website and complete the online application form. You'll need your transcripts, test scores, and recommendation letters. Would you like details on specific programs?"),
        (r'deadline|when is.*due', 
         "Application deadlines vary by program. Undergraduate deadlines are typically December 1 for Early Action and February 1 for Regular Decision. Graduate programs may have different dates. Want me to check a specific program?"),
        (r'requirements|eligibility', 
         "Basic requirements include a high school diploma or equivalent, standardized test scores (SAT/ACT for undergrad), and English proficiency for international students. Specific programs may have additional requirements. Which program are you interested in?"),
        (r'tuition|cost|fees', 
         "Tuition varies by program and residency status. For 2025-2026, undergraduate tuition is approximately $30,000/year for in-state and $50,000/year for out-of-state. Would you like details on financial aid?"),
        (r'financial aid|scholarship', 
         "We offer merit-based scholarships, need-based grants, and student loans. Complete the FAFSA to apply for federal aid. Want tips on scholarship applications?"),
        (r'program|major|course', 
         "We offer over 100 majors, including Computer Science, Engineering, Business, and more. Tell me what you're interested in, and I can provide details!"),
        (r'contact|reach out', 
         "You can contact our admissions office at admissions@university.edu or call (123) 456-7890. Office hours are 9 AM to 5 PM, Monday to Friday. Need help with something specific?"),
        (r'hi|hello|hey', 
         "Hello! I'm here to help with your university admission questions. What's on your mind?"),
    ]
    
    # Check for matching patterns
    for pattern, response in patterns:
        if re.search(pattern, user_message):
            return response
    
    # Default response for unrecognized queries
    return "I'm not sure about that. Could you clarify or ask something else about admissions?"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    bot_response = get_bot_response(user_message)
    return jsonify({'response': bot_response})

if __name__ == '__main__':
    app.run(debug=True)