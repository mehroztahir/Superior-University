from flask import Flask, render_template, request, jsonify, session
import uuid
from travel_data import destinations, get_recommendations

app = Flask(__name__)
app.secret_key = str(uuid.uuid4())

# Conversation flow configuration
QUESTIONS = [
    {"question": "What kind of trip do you want? (beach/mountain/city/adventure)", "field": "interests"},
    {"question": "Do you prefer warm or cold weather?", "field": "temperature"},
    {"question": "What's your budget? (budget/moderate/luxury)", "field": "budget"},
    {"question": "When are you traveling? (summer/winter/spring/fall)", "field": "season"}
]

COMMON_RESPONSES = {
    'greetings': ['hello', 'hi', 'hey'],
    'affirmative': ['yes', 'yeah', 'y', 'sure'],
    'negative': ['no', 'n', 'nah'],
    'exit': ['quit', 'exit', 'q']
}

def process_user_input(text, field):
    """Process user input based on the expected field"""
    text = text.lower().strip()
    
    if field == "interests":
        interest_map = {
            "beach": ["beach", "sea", "ocean", "coast", "sand"],
            "mountain": ["mountain", "alps", "hike", "trek", "peak"],
            "city": ["city", "urban", "metropolis", "downtown"],
            "adventure": ["adventure", "trek", "explore", "thrill"]
        }
        for interest, keywords in interest_map.items():
            if any(word in text for word in keywords):
                return interest
        return None
    
    elif field == "temperature":
        if any(word in text for word in ["warm", "hot", "tropical"]):
            return "warm"
        elif any(word in text for word in ["cold", "cool", "snow", "freez"]):
            return "cold"
        return None
    
    elif field == "budget":
        if any(word in text for word in ["luxury", "high", "expensive", "premium"]):
            return "luxury"
        elif any(word in text for word in ["budget", "low", "cheap", "economy"]):
            return "budget"
        elif any(word in text for word in ["moderate", "medium", "average"]):
            return "moderate"
        return None
    
    elif field == "season":
        seasons = ["summer", "winter", "spring", "fall", "autumn"]
        for season in seasons:
            if season in text:
                return season
        return None

@app.route('/')
def home():
    """Reset session and serve the chat interface"""
    session.clear()
    session['step'] = 0
    session['prefs'] = {}
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat messages and return responses"""
    user_input = request.form['message'].lower().strip()
    
    # Initialize session if needed
    if 'step' not in session:
        session['step'] = 0
        session['prefs'] = {}

    # Handle exit commands
    if user_input in COMMON_RESPONSES['exit']:
        session.clear()
        return jsonify({
            "response": "Goodbye! Refresh the page to start a new conversation.",
            "conversation_ended": True
        })

    # Process current question
    if session['step'] < len(QUESTIONS):
        current_question = QUESTIONS[session['step']]
        processed_input = process_user_input(user_input, current_question['field'])
        
        if processed_input:
            session['prefs'][current_question['field']] = processed_input
            session['step'] += 1
            
            if session['step'] < len(QUESTIONS):
                return jsonify({
                    "response": QUESTIONS[session['step']]['question'],
                    "done": False
                })
    
    # Get recommendations if all questions answered
    if session['step'] >= len(QUESTIONS):
        recommendations = get_recommendations(session['prefs'])
        
        if not recommendations:
            response = "I couldn't find destinations matching all your preferences."
        else:
            response = "✈️ Here are my top picks:\n\n" + "\n\n".join(
                f"📍 <strong>{place['name']}</strong>\n"
                f"   - {place.get('description', '')}\n"
                f"   - Best for: {', '.join(place.get('tags', []))}\n"
                f"   - Budget: {place.get('budget', '').capitalize()}\n"
                f"   - Best season: {', '.join(place.get('best_season', ['Year-round']))}"
                for place in recommendations[:3]
            )
        
        response += "\n\nWould you like another recommendation? (yes/no)"
        return jsonify({
            "response": response,
            "done": True,
            "conversation_ended": False
        })
    
    return jsonify({
        "response": QUESTIONS[session['step']]['question'],
        "done": False
    })

if __name__ == '__main__':
    app.run(debug=True)