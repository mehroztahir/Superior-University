document.addEventListener('DOMContentLoaded', () => {
    const chatBox = document.getElementById('chatBox');
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    const typingIndicator = document.getElementById('typingIndicator');

    function addMessage(text, isUser = false) {
        const msgDiv = document.createElement('div');
        msgDiv.className = isUser ? 'user-message' : 'bot-message';
        msgDiv.innerHTML = text.replace(/\n/g, '<br>');
        chatBox.appendChild(msgDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function showTyping() {
        typingIndicator.style.display = 'flex';
    }

    function hideTyping() {
        typingIndicator.style.display = 'none';
    }

    function disableInput() {
        userInput.disabled = true;
        sendButton.disabled = true;
        userInput.placeholder = "Refresh page to start new conversation";
    }

    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;
        
        addMessage(message, true);
        userInput.value = '';
        showTyping();
        
        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `message=${encodeURIComponent(message)}`
            });
            const data = await response.json();
            
            hideTyping();
            addMessage(data.response);
            
            if (data.conversation_ended) {
                disableInput();
            } else if (data.done) {
                userInput.placeholder = "Type 'no' to exit or ask another question";
            }
        } catch (error) {
            hideTyping();
            addMessage("⚠️ Sorry, I'm having trouble. Try again later.");
            console.error('Error:', error);
        }
    }

    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    // Focus input field when page loads
    userInput.focus();
});