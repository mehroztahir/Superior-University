def process_user_input(text, field):
    text = text.lower().strip()
    
    if field == "interests":
        interest_map = {
            "beach": ["beach", "sea", "ocean", "coast"],
            "mountain": ["mountain", "alps", "hike", "trek"],
            "city": ["city", "urban", "metropolis"],
            "adventure": ["adventure", "trek", "explore"]
        }
        return [k for k, v in interest_map.items() if any(word in text for word in v)]
    
    elif field == "temperature":
        return "warm" if "warm" in text else "cold"
    
    elif field == "budget":
        if any(word in text for word in ["luxury", "high", "expensive"]):
            return "luxury"
        elif any(word in text for word in ["budget", "low", "cheap"]):
            return "budget"
        return "moderate"
    
    elif field == "season":
        seasons = ["summer", "winter", "spring", "fall"]
        return next((s for s in seasons if s in text), None)
    
    return None