destinations = [
    # COLD WEATHER DESTINATIONS (Winter)
    {
        "name": "Swiss Alps, Switzerland",
        "description": "World-class skiing with charming alpine villages",
        "budget": "luxury",
        "temperature": "cold",
        "tags": ["skiing", "mountain", "adventure"],
        "best_season": ["winter"],
        "highlights": ["Jungfrau region", "Zermatt", "Thermal baths"]
    },
    {
        "name": "Hokkaido, Japan",
        "description": "Powdery snow and steaming hot springs",
        "budget": "moderate",
        "temperature": "cold",
        "tags": ["skiing", "culture", "food"],
        "best_season": ["winter"],
        "highlights": ["Sapporo Snow Festival", "Niseko powder snow"]
    },

    # WARM WEATHER DESTINATIONS
    {
        "name": "Bali, Indonesia",
        "description": "Tropical beaches and vibrant culture",
        "budget": "moderate",
        "temperature": "warm",
        "tags": ["beach", "yoga", "culture"],
        "best_season": ["summer", "spring"],
        "highlights": ["Ubud temples", "Seminyak beaches", "Uluwatu cliffs"]
    },
    {
        "name": "Phuket, Thailand",
        "description": "Crystal-clear waters and lush jungles",
        "budget": "budget",
        "temperature": "warm",
        "tags": ["beach", "island", "party"],
        "best_season": ["winter", "spring"],
        "highlights": ["Phi Phi Islands", "Old Phuket Town", "Night markets"]
    },

    # YEAR-ROUND DESTINATIONS
    {
        "name": "Barcelona, Spain",
        "description": "Cosmopolitan city with beach access",
        "budget": "moderate",
        "temperature": "mild",
        "tags": ["city", "culture", "beach"],
        "best_season": ["spring", "fall", "summer"],
        "highlights": ["Sagrada Familia", "Gothic Quarter", "Tapas bars"]
    },
    {
        "name": "Cape Town, South Africa",
        "description": "Stunning landscapes and diverse culture",
        "budget": "moderate",
        "temperature": "mild",
        "tags": ["mountain", "wine", "wildlife"],
        "best_season": ["summer", "fall"],
        "highlights": ["Table Mountain", "Penguin Beach", "Winelands"]
    },

    # ADVENTURE DESTINATIONS
    {
        "name": "Queenstown, New Zealand",
        "description": "Adventure capital with fjords and mountains",
        "budget": "moderate",
        "temperature": "mild",
        "tags": ["adventure", "hiking", "scenic"],
        "best_season": ["summer", "winter"],
        "highlights": ["Bungee jumping", "Milford Sound", "Ski resorts"]
    }
]

def get_recommendations(preferences):
    """Enhanced matching algorithm with seasonal priority"""
    scored_destinations = []
    
    for dest in destinations:
        score = 0
        
        # Temperature match (3 points)
        if not preferences.get("temperature") or dest["temperature"] == preferences["temperature"]:
            score += 3
        
        # Budget match (2 points)
        if not preferences.get("budget") or dest["budget"] == preferences["budget"]:
            score += 2
        
        # Season match (2 points)
        if not preferences.get("season") or preferences["season"] in dest.get("best_season", []):
            score += 2
        
        # Interests match (1 point per matching tag)
        if preferences.get("interests"):
            score += sum(1 for tag in preferences["interests"] if tag in dest["tags"])
        
        if score > 0:
            scored_destinations.append((dest, score))
    
    # Sort by score (descending) and return top 3
    scored_destinations.sort(key=lambda x: x[1], reverse=True)
    return [dest for dest, score in scored_destinations[:3]]